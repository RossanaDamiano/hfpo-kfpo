$(document).foundation();
// al caricamento della pagina ad ogni .button-header viene aggiunto il listener per l'evento click
// quando viene cliccato un .button-header viene rimossa la classe selected a tutti gli altri .button-header
// e viene aggiunta la classe selected al .button-header cliccato
$(".button-header").on("click", function() {
    $(".button-header").removeClass("selected");
    $(this).addClass("selected");
});
