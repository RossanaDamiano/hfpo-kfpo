function clearFields(){
    var checkboxes=document.getElementsByClassName("check")

    for(var i=0;i<checkboxes.length;i++){
        checkboxes[i].checked=false
        $(document).ready(function() {
            $('.queryCol *').prop('disabled', false);
        });
    }

    document.getElementById("kindOfRelation").value="administrativeKindOfRelation"
    document.getElementById("totRelation").value="administrativeTotRelation"
    document.getElementById("name").value=""
    document.getElementById("type").value=""
    document.getElementById("OOT").value=""
    document.getElementById("source").value="default"
    document.getElementById("occursOnLine").checked=false
    document.getElementById("totAdminKinshipCheck").checked=false
    document.getElementById("totAdminKinship").value=""
    
}

function search() {
   var disable=document.getElementById("name").disabled
    if(disable==true){
        var checkboxes=document.getElementsByClassName("check")
        var selectedCheck=""
        for(var i=0;i<checkboxes.length;i++){
            if(checkboxes[i].checked==true){
                selectedCheck=checkboxes[i].value
            }
        }
        var groupBy=""
        var select=""
        var where=""
        var selectedTot=document.getElementById("totRelation").value
        if(selectedCheck !== "" && selectedTot =="administrativeTotRelation"){
            var selectedType=document.getElementById("totAdminKinship").value

            select='?type (count(?link) as ?tot)'
            where='?link a <kfpo:AdministrativeRelationshipFactoid>.\n\
                ?link dcterms:title ?name.\n\
                bind('+'"'+selectedType+'"'+' as ?type)\n\
                ?link <kfpo:administrativeRelationType> ?type.\n'
            groupBy="?type"
        }else if(selectedCheck!=="" && selectedTot=="kinshipTotRelation"){
            var selectedType=document.getElementById("totAdminKinship").value

            select='?type (count(?link) as ?tot)'
            where='?link a <kfpo:KinshipFactoid>.\n\
                ?link dcterms:title ?name.\n\
                bind('+'"'+selectedType+'"'+' as ?type)\n\
                ?link <kfpo:kinshipTie> ?type.\n'
            groupBy="?type"
        }
        //aggiunta Rossana
        else{ 

            if(selectedCheck!=="" && selectedTot=="akluTotRelation"){

                var selectedType=document.getElementById("totAdminKinship").value

                select='?type (count(?link) as ?tot)'
                where='?link a <kfpo:Aklu>.\n\
                    ?link dcterms:title ?name.\n\
                    bind('+'"'+selectedType+'"'+' as ?type)\n\
                    ?link <kfpo:akluType> ?type.\n'
                groupBy="?type"
           }  
        }

        var query='PREFIX dcterms: <http://purl.org/dc/terms/>\n\
                select '+ select+ '\n\
                where{\n\
                    '+where+'\
                }group by '+groupBy 
        
    }else{
        var selectedKindOfRelation=document.getElementById("kindOfRelation").value
        var selectedName=document.getElementById("name").value
        var selectedType=document.getElementById("type").value
        var checkOccursOnLine=document.getElementById("occursOnLine").checked
        var selectedOOT=document.getElementById("OOT").value

        var where=""
        var select=""
        var name="?name"
        var groupBy=""

        if(selectedName !== ""){
            select=select+" "
            where=where+" "
            name='"'+selectedName+'"'
        }

        if(selectedKindOfRelation == "administrativeKindOfRelation"){
            valuesRel="<kfpo:hasAdministrativeReference>"
        }else if(selectedKindOfRelation=="kinshipKindOfRelation"){
            valuesRel="<kfpo:hasKinshipReference>"
        }else {
            valuesRel="<kfpo:akluType>"
            //Completare con alternative che collegano Aklu con persone
        }


        if(selectedType !== "" && selectedKindOfRelation=="administrativeKindOfRelation"){
            where=where+' bind('+'"'+selectedType+'"'+' as ?type)\n\
                    ?linkFactoid <kfpo:administrativeRelationType> ?type.\n'
           groupBy="order by ?nameFactoid"
        }else if(selectedType !== "" && selectedKindOfRelation=="kinshipKindOfRelation"){
            where=where+' bind('+'"'+selectedType+'"'+' as ?type)\n\
                    ?linkFactoid <kfpo:kinshipTie> ?type.\n'
            groupBy="order by ?nameFactoid"
        }
        else {
            //aggiunto 
            where=where+' bind('+'"'+selectedType+'"'+' as ?type)\n\
                    ?linkFactoid <kfpo:akluType> ?type.\n'
            groupBy="order by ?nameFactoid"

        }

        if(checkOccursOnLine == true){
            var selectedSource=document.getElementById("source").value
            if(selectedSource==""){
                selectedSource="?source"
            }else{
                selectedSource='"'+selectedSource+'"'
            }
            select=select+" ?occurOnLine"
            where=where+' bind("paired with" as ?type)\n\
                        ?linkFactoid <kfpo:administrativeRelationType> ?type.\n\
                        ?linkFactoid <kfpo:occursOnLine> ?occurOnLine.\n\
                        ?linkFactoid <kfpo:sourcedFrom> ?linkSource.\n\
                        bind('+selectedSource+' as ?source)\n\
                        ?linkSource dcterms:title ?source.\n'
            groupBy="group by ?IDFactoid ?name ?nameFactoid ?source ?linkSource ?occurOnLine order by xsd:integer(?occurOnLine)"
        }
        if(selectedOOT !== ""){
            select=select+" ?objectOfTransaction"
            where=where+' bind('+'"'+selectedOOT+'"'+' as ?objectOfTransaction)\n\
                ?linkFactoid <kfpo:objectOfTransaction> ?objectOfTransaction.'
            groupBy="order by ?nameFactoid"
        }


        var query='PREFIX dcterms: <http://purl.org/dc/terms/>\n\
                PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\n\
                PREFIX o: <http://omeka.org/s/vocabs/o#>\n\
                select distinct ?IDFactoid ?nameFactoid'+ select+ '\n\
                where{\n\
                    ?linkName a <kfpo:KassitePerson>.\n\
                    bind('+name+' as ?name)\n\
                    ?linkName dcterms:title ?name.\n\
                    ?linkName ?relation ?linkFactoid.\n\
                    values ?relation {'+valuesRel+'}\n\
                    ?linkFactoid dcterms:title ?nameFactoid.\n\
                    ?linkFactoid o:id ?IDFactoid.\n\
                    '+where+'\
                }'+groupBy 
    }

    $.when(executeAjax("https://fuseki.hfpo-kfpo.di.unito.it/KFPO/?query=",query)).done(function(res){
        console.log(res)
        console.log(query)
        document.getElementById("collapsibleHead").checked=false
            var header=""
            var data=""
            var body=""
            var table=""
            var noData=""

            for(var i=0;i<res.head.vars.length;i++){
                if(res.head.vars[i]!=="IDFactoid"){
                    header=header+'<th>'+res.head.vars[i]+'</th>'
                }
                
            }
            header='<tr>'+header+'</tr>'

            for(var j=0;j<res.results.bindings.length;j++){
                data=""
                if(res.results.bindings[j].nameFactoid !== undefined){
                    data=data+"<td><a href=https://kfpo.di.unito.it/s/KPR/item/"+
                    res.results.bindings[j].IDFactoid.value+" target='_blank'>"
                    +res.results.bindings[j].nameFactoid.value+"</a></td>"
                }
                if(res.results.bindings[j].objectOfTransaction !== undefined){
                    data=data+"<td>"+res.results.bindings[j].objectOfTransaction.value+"</td>"
                }
                if(res.results.bindings[j].occurOnLine !== undefined){
                    data=data+"<td>"+res.results.bindings[j].occurOnLine.value+"</td>"
                }
                if(res.results.bindings[j].type !== undefined){
                    data=data+"<td>"+res.results.bindings[j].type.value+"</td>"
                }
                if(res.results.bindings[j].tot !== undefined){
                    data=data+"<td>"+res.results.bindings[j].tot.value+"</td>"
                }

                body=body+"<tr>"+data+"</tr>"
            }

            if(res.results.bindings.length == 0){
                noData = "<h4 id='noData'>No data available in table</h4>"
            }
            
            table="<table class='tResult'><h4>Showing "+ j +" entries</h4>"+header+body+"</table>"+noData
            document.getElementById("result").innerHTML=table
    });
}

/*
function changeType(e){
    if(e.target.value=="administrativeKindOfRelation"){
        takeCustom("19","typeList",true)
        document.getElementById("type").value=""
    }else if(e.target.value=="kinshipKindOfRelation"){
        takeCustom("18","typeList",true)
        document.getElementById("type").value=""
    }
}
*/

function changeType(e){
    switch(e.target.value) {    
    
    case "administrativeKindOfRelation": {
        takeCustom("19","typeList",true)
        document.getElementById("type").value=""
        }
        break;
    case "kinshipKindOfRelation" : {
        takeCustom("18","typeList",true)
        document.getElementById("type").value=""
        }
        break;
    case "akluKindOfRelation" : {
        takeCustom("26","typeList",true)
        document.getElementById("type").value=""
        }
        break;
        }
    }  


/*
function changeAdminKin(e){
    if(e.target.value=="administrativeTotRelation"){
        takeCustom("19","totAdminKinshipList",true)
        document.getElementById("totAdminKinship").value=""
    }else if(e.target.value=="kinshipTotRelation"){
        takeCustom("18","totAdminKinshipList",true)
        document.getElementById("totAdminKinship").value=""
    }
}
*/

//Rossana Versione per aklu
function changeAdminKin(e){
    switch(e.target.value) {    
    
    case "administrativeTotRelation": {
        takeCustom("19","totAdminKinshipList",true)
        document.getElementById("totAdminKinship").value=""
        }
        break;
    case "kinshipTotRelation" : {
        takeCustom("18","totAdminKinshipList",true)
        document.getElementById("totAdminKinship").value=""
        }
        break;
    case "akluTotRelation" : {
        takeCustom("26","totAdminKinshipList",true)
        document.getElementById("totAdminKinship").value=""
        }
        break;
        }
    }    



function takeOccurs(id){
    var query='PREFIX dcterms: <http://purl.org/dc/terms/>\
        PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>\
        PREFIX o: <http://omeka.org/s/vocabs/o#>\
        select distinct ?source \
        where{\
        ?linkName a <kfpo:KassitePerson>.\
        ?linkName ?relation ?linkFactoid.\
        values ?relation {<kfpo:hasAdministrativeReference>}\
        bind("paired with" as ?type)\
        ?linkFactoid <kfpo:administrativeRelationType> ?type.\
        ?linkFactoid <kfpo:occursOnLine> ?occurOnLine.\
        ?linkFactoid <kfpo:sourcedFrom> ?linkSource.\
        bind(?source as ?source)\
        ?linkSource dcterms:title ?source.\
        }order by ?source'
    $.when(executeAjax("https://fuseki.hfpo-kfpo.di.unito.it/KFPO/?query=",query)).done(function(res){
        var opt=""
        for(var i=0;i<res.results.bindings.length;i++){
            opt=opt+'<option value="'+res.results.bindings[i].source.value+'">'+res.results.bindings[i].source.value
            +'</option>'
        }
        opt="<option value='default'>Choose a text..."+opt
            document.getElementById(id).innerHTML=opt
    });
}