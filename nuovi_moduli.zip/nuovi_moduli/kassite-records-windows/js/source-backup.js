function clearFieldsSource(){
    document.getElementById("publication").value=""
    document.getElementById("textNo").value=""
    document.getElementById("collection").value=""
    document.getElementById("collectionNo").value=""
    document.getElementById("genre").value=""
    document.getElementById("subgenre").value=""
    document.getElementById("subjectMatter").value=""
    document.getElementById("sealedBy").value=""
    document.getElementById("sealedWith").value=""
    document.getElementById("TypeOfSealing").value=""
    document.getElementById("kingX").value="" 
    document.getElementById("yearX").value="" 
    document.getElementById("monthX").value="" 
    document.getElementById("kingY").value="" 
    document.getElementById("yearY").value="" 
    document.getElementById("monthY").value="" 
}

function searchSource() {
    //alert("eccomi");
    var selectedPublication=document.getElementById("publicationS").value
    var selectedTextNo=document.getElementById("textNoS").value
    var selectedCollection=document.getElementById("collectionS").value
    var selectedCollectionNo=document.getElementById("collectionNoS").value
    var selectedGenre=document.getElementById("genre").value
    var selectedSubgenre=document.getElementById("subgenre").value
    var selectedSubjectMatter=document.getElementById("subjectMatter").value
    var selectedSealedBy=document.getElementById("sealedBy").value
    var selectedSealedWith=document.getElementById("sealedWith").value
    var selectedTypeOfSealing=document.getElementById("TypeOfSealing").value
    var selectedKingX=document.getElementById("kingX").value
    var selectedYearX=document.getElementById("yearX").value
    var selectedMonthX=document.getElementById("monthX").value
    var selectedKingY=document.getElementById("kingY").value
    var selectedYearY=document.getElementById("yearY").value
    var selectedMonthY=document.getElementById("monthY").value

    var where=""
    var select=""
    var publication="?volume"
    var textNo="?textNo"
    var collection="?collection"
    var collectionNo="?collectionNo"
    var kingValues=""
    var yearValues=""
    var monthValues=""
    var other=""
    var bodyTot=""
    var sommaDoc=0
    var orderBy=""
    var union=""

    var listKing="Burna-Buriaš II\nKurigalzu II\nNazi-Maruttaš\nKadašman-Turgu\nKadašman-Enlil II\nKudur-Enlil\nŠagarakti-Šuriaš\nKaštiliaš (IV)\nAdad-šuma-iddina\nAdad-šuma-uṣur\nMeli-Šipak\nn.d.\nn.p.".split("\n")
    var listMonth="I\nII\nIII\nIV\nV\nVI\nVIa\nVII\nVIII\nIX\nX\nXI\nXII\nXIIa\nn.d.\nn.p.".split("\n")
    var listYear="1\n2\n3\n4\n5\n6\n7\n8\n9\n10\n11\n12\n13\n14\n15\n16\n17\n18\n19\n20\n21\n22\n23\n24\n25\n26\n27\n28\n29\n30\nn.d.\nn.p.".split("\n")

    if(selectedPublication !== ""){
        publication='"'+selectedPublication+'"'
        orderBy=orderBy+" ?textNo"
    }
    if(selectedTextNo !== ""){
        textNo='"'+selectedTextNo+'"'
        orderBy=orderBy+" ?volume"
    }
    if(selectedCollection !== ""){
        collection='"'+selectedCollection+'"'
        orderBy=orderBy+" ?collectionNo"
    }
    if(selectedCollectionNo !== ""){
        collectionNo='"'+selectedCollectionNo+'"'
        orderBy=orderBy+" ?collection"
    }
    if(selectedGenre !== ""){
        select=select+" ?genre"
        where=where+' bind('+'"'+selectedGenre+'"'+' as ?genre)\n\
            ?linkSource <kfpo:genre> ?genre.\n'
    }
    if(selectedSubgenre !== ""){
        select=select+" ?subgenre"
        where=where+' bind('+'"'+selectedSubgenre+'"'+' as ?subgenre)\n\
            ?linkSource <kfpo:subGenre> ?subgenre.\n'
    }
    if(selectedSubjectMatter !== ""){
        select=select+" ?subjectMatter"
        where=where+' bind('+'"'+selectedSubjectMatter+'"'+' as ?subjectMatter)\n\
            ?linkSource dcterms:subject ?subjectMatter.\n'
    }
    if(selectedSealedBy !== ""){
        select=select+" ?sealedBy"
        where=where+' bind('+'"'+selectedSealedBy+'"'+' as ?sealedBy)\n\
            ?linkSource <kfpo:sealedBy> ?linkSealedBy.\n\
            ?linkSealedBy dcterms:title ?sealedBy\n'
    }
    if(selectedSealedWith !== ""){
        select=select+" ?sealedWith"
        where=where+' bind('+'"'+selectedSealedWith+'"'+' as ?sealedWith)\n\
            ?linkSource <kfpo:sealedWith> ?linkSealedWith.\n\
            ?linkSealedWith dcterms:title ?sealedWith\n'
    }
    if(selectedTypeOfSealing !== ""){
        select=select+" ?typeOfSealing"
        where=where+' bind('+'"'+selectedTypeOfSealing+'"'+' as ?typeOfSealing)\n\
            ?linkSource <kfpo:sealing> ?typeOfSealing.\n'
    }
    if(selectedKingX!=="" && selectedKingY==""){
        select=select+" ?king"
        where=where+' bind('+'"'+selectedKingX+'"'+' as ?king)\n\
            ?linkSource <kfpo:king> ?king.\n'
    }
    if(selectedYearX!=="" && selectedYearY==""){
        select=select+" ?year"
        where=where+' bind('+'"'+selectedYearX+'"'+' as ?year)\n\
            ?linkSource <kfpo:year> ?year.\n'
    }
    if(selectedMonthX!=="" && selectedMonthY==""){
        select=select+" ?month"
        where=where+' bind('+'"'+selectedMonthX+'"'+' as ?month)\n\
            ?linkSource <kfpo:month> ?month.\n'
    }
    //only king
    if(selectedKingX !== "" && selectedKingY !== "" && selectedMonthX == "" && selectedMonthY == "" 
    && selectedYearX == "" && selectedYearY ==""){
        var initKing=listKing.indexOf(selectedKingX)
        var finalKing=listKing.indexOf(selectedKingY)

        if(initKing<=finalKing){
            for(var k=initKing;k<=finalKing;k++){
                kingValues=kingValues+'(<kfpo:king> '+'"'+listKing[k]+'"'+')'
            }
            kingValues="values(?k ?king){"+kingValues+"}"
            other="?linkSource <kfpo:year> ?year.\n\
                ?linkSource <kfpo:month> ?month.\n\
                ?linkSource ?k ?king."
            $.when(executeRange(kingValues,yearValues,monthValues,other,select,where)).done(function(res){
                printRes(res)
            })
        }else{
            document.getElementById("result").innerHTML="<h4 id='noData'>Inconsistent range!</h4>"
            
        }
    }
    //only year
    if(selectedKingX == "" && selectedKingY == "" && selectedMonthX == "" && selectedMonthY == "" 
    && selectedYearX !== "" && selectedYearY !==""){
        var initYear=listYear.indexOf(selectedYearX)
        var finalYear=listYear.indexOf(selectedYearY)

        if(initYear<=finalYear){
            for(var y=initYear;y<=finalYear;y++){
                yearValues=yearValues+'(<kfpo:year> '+'"'+listYear[y]+'"'+')'
            }
            yearValues="values(?y ?year){"+yearValues+"}"
            other="?linkSource <kfpo:king> ?king.\n\
                ?linkSource <kfpo:month> ?month.\n\
                ?linkSource ?y ?year." 
            $.when(executeRange(kingValues,yearValues,monthValues,other,select,where)).done(function(res){
                printRes(res)
            })
        }else{
            document.getElementById("result").innerHTML="<h4 id='noData'>Inconsistent range!</h4>"
            
        }
    }
    //only month
    if(selectedKingX == "" && selectedKingY == "" && selectedMonthX !== "" && selectedMonthY !== "" 
    && selectedYearX == "" && selectedYearY ==""){
        var initMonth=listMonth.indexOf(selectedMonthX)
        var finalMonth=listMonth.indexOf(selectedMonthY)

        if(initMonth<=finalMonth){
            for(var m=initMonth;m<=finalMonth;m++){
                monthValues=monthValues+'(<kfpo:month> '+'"'+listMonth[m]+'"'+')'
            }
            monthValues="values(?m ?month){"+monthValues+"}"
            other="?linkSource <kfpo:king> ?king.\n\
                ?linkSource <kfpo:year> ?year.\n\
                ?linkSource ?m ?month." 
            $.when(executeRange(kingValues,yearValues,monthValues,other,select,where)).done(function(res){
                printRes(res)
            })
        }else{
            document.getElementById("result").innerHTML="<h4 id='noData'>Inconsistent range!</h4>"
            
        }
    }
    //king-year
    if(selectedKingX !== "" && selectedKingY !== "" && selectedMonthX == "" && selectedMonthY == "" 
    && selectedYearX !== "" && selectedYearY !==""){
        var initKing=listKing.indexOf(selectedKingX)
        var finalKing=listKing.indexOf(selectedKingY)
        var initYear=listYear.indexOf(selectedYearX)
        var finalYear=listYear.indexOf(selectedYearY)

        if((initKing==finalKing && initYear<=finalYear) || (initKing!==finalKing && initYear<=finalYear)){
            for(var k=initKing;k<=finalKing;k++){
                kingValues=""
                yearValues=""
                var yearRange=[]
                if(initKing==finalKing){ //same king
                    for(var i=initYear;i<=finalYear;i++){
                        yearRange.push(listYear[i])  
                    }
                    kingValues=kingValues+'(<kfpo:king> '+'"'+listKing[k]+'"'+')'
                    kingValues="values(?k ?king){"+kingValues+"}"
                }else{ //different king
                    if(k==initKing){
                        for(var i=initYear;i<listYear.length-2;i++){
                            yearRange.push(listYear[i])
                        }
                        kingValues=kingValues+'(<kfpo:king> '+'"'+listKing[k]+'"'+')'
                        kingValues="values(?k ?king){"+kingValues+"}"
                    }else if(k==finalKing){
                        for(var i=0;i<=finalYear;i++){
                            yearRange.push(listYear[i])
                        }
                        kingValues=kingValues+'(<kfpo:king> '+'"'+listKing[k]+'"'+')'
                        kingValues="values(?k ?king){"+kingValues+"}"
                    }else{
                        for(var i=0;i<listYear.length-2;i++){
                            yearRange.push(listYear[i])
                        }
                        for(var i=k;i<finalKing;i++){
                            kingValues=kingValues+'(<kfpo:king> '+'"'+listKing[i]+'"'+')'
                        }
                        kingValues="values(?k ?king){"+kingValues+"}"
                        k=finalKing-1
                    }
                    
                }
                for(var y=0;y<yearRange.length;y++){
                    yearValues=yearValues+'(<kfpo:year> '+'"'+yearRange[y]+'"'+')'
                }
                yearValues="values(?y ?year){"+yearValues+"}"
                other="?linkSource ?k ?king.\n\
                ?linkSource ?y ?year.\n\
                ?linkSource <kfpo:month> ?month."
                var u="union"
                if(k==finalKing){
                    union=union+'{'+kingValues+yearValues+'}'
                }else{
                    union=union+'{'+kingValues+yearValues+'}'+u
                }
            }
            $.when(executeRange(union,other,select,where)).done(function(res){
                    console.log(res)
                    printRes(res)
                })
        }else{
            document.getElementById("result").innerHTML="<h4 id='noData'>Inconsistent range!</h4>"
        }
    }
    //king-month
    if(selectedKingX !== "" && selectedKingY !== "" && selectedMonthX !== "" && selectedMonthY !== "" 
    && selectedYearX == "" && selectedYearY ==""){
        var initKing=listKing.indexOf(selectedKingX)
        var finalKing=listKing.indexOf(selectedKingY)
        var initMonth=listMonth.indexOf(selectedMonthX)
        var finalMonth=listMonth.indexOf(selectedMonthY)

        if((initKing==finalKing && initMonth<=finalMonth) || (initKing!==finalKing && initMonth<=finalMonth)){
            for(var k=initKing;k<=finalKing;k++){
                kingValues=""
                monthValues=""
                var monthRange=[]
                if(initKing==finalKing){ //same king
                    for(var i=initMonth;i<=finalMonth;i++){
                        monthRange.push(listMonth[i])  
                    }
                    kingValues=kingValues+'(<kfpo:king> '+'"'+listKing[k]+'"'+')'
                    kingValues="values(?k ?king){"+kingValues+"}"
                }else{ //different king
                    if(k==initKing){
                        for(var i=initMonth;i<listMonth.length-2;i++){
                            monthRange.push(listMonth[i])
                        }
                        kingValues=kingValues+'(<kfpo:king> '+'"'+listKing[k]+'"'+')'
                        kingValues="values(?k ?king){"+kingValues+"}"
                    }else if(k==finalKing){
                        for(var i=0;i<=finalMonth;i++){
                            monthRange.push(listMonth[i])
                        }
                        kingValues=kingValues+'(<kfpo:king> '+'"'+listKing[k]+'"'+')'
                        kingValues="values(?k ?king){"+kingValues+"}"
                    }else{
                        for(var i=0;i<listMonth.length-2;i++){
                            monthRange.push(listMonth[i])
                        }
                        for(var i=k;i<finalKing;i++){
                            kingValues=kingValues+'(<kfpo:king> '+'"'+listKing[i]+'"'+')'
                        }
                        kingValues="values(?k ?king){"+kingValues+"}"
                        k=finalKing-1
                    }
                    
                }
                
                for(var m=0;m<monthRange.length;m++){
                    monthValues=monthValues+'(<kfpo:month> '+'"'+monthRange[m]+'"'+')'
                }
                monthValues="values(?m ?month){"+monthValues+"}"
                other="?linkSource ?k ?king.\n\
                ?linkSource ?m ?month.\n\
                ?linkSource <kfpo:year> ?year." 
                var u="union"
                if(k==finalKing){
                    union=union+'{'+kingValues+monthValues+'}'
                }else{
                    union=union+'{'+kingValues+monthValues+'}'+u
                }
            }
            $.when(executeRange(union,other,select,where)).done(function(res){
                console.log(res)
                printRes(res)
            })
        }else{
            document.getElementById("result").innerHTML="<h4 id='noData'>Inconsistent range!</h4>"
            
        }
    }
    //king-year-month
    if(selectedKingX !== "" && selectedKingY !== "" && selectedMonthX !== "" && selectedMonthY !== "" 
    && selectedYearX !=="" && selectedYearY !==""){
        var initKing=listKing.indexOf(selectedKingX)
        var finalKing=listKing.indexOf(selectedKingY)
        var initMonth=listMonth.indexOf(selectedMonthX)
        var finalMonth=listMonth.indexOf(selectedMonthY)
        var initYear=listYear.indexOf(selectedYearX)
        var finalYear=listYear.indexOf(selectedYearY)

        if((initKing==finalKing && initYear<=finalYear) || (initKing!==finalKing && initYear<=finalYear)){
            var monthRange=[]
            var k=""
            if(initKing==finalKing){ //1 2 3 4
                if(initYear==finalYear){ //1 2
                    for(var i=initMonth;i<=finalMonth;i++){
                        monthRange.push(listMonth[i])
                    }
                    kingValues=kingValues+'(<kfpo:king> '+'"'+listKing[initKing]+'"'+')'
                    kingValues="values(?k ?king){"+kingValues+"}"
                    yearValues=yearValues+'(<kfpo:year> '+'"'+listYear[initYear]+'"'+')'
                    yearValues="values(?y ?year){"+yearValues+"}"
                    for(var m=0;m<monthRange.length;m++){
                        monthValues=monthValues+'(<kfpo:month> '+'"'+monthRange[m]+'"'+')'
                    }
                    monthValues="values(?m ?month){"+monthValues+"}"
                    union=union+'{'+kingValues+yearValues+monthValues+'}'
                    other="?linkSource ?k ?king.\n\
                        ?linkSource ?m ?month.\n\
                        ?linkSource ?y ?year." 
                }else{ //3 4
                    for(var y=initYear;y<=finalYear;y++){
                        yearValues=""
                        kingValues=""
                        monthValues=""
                        monthRange=[]
                        if(y==initYear){
                            for(var i=initMonth;i<listMonth.length-2;i++){
                                monthRange.push(listMonth[i])
                            }
                            yearValues=yearValues+'(<kfpo:year> '+'"'+listYear[y]+'"'+')'
                            yearValues="values(?y ?year){"+yearValues+"}"
                        }else if(y==finalYear){
                            for(var i=0;i<=finalMonth;i++){
                                monthRange.push(listMonth[i])
                            }
                            yearValues=yearValues+'(<kfpo:year> '+'"'+listYear[y]+'"'+')'
                            yearValues="values(?y ?year){"+yearValues+"}"
                        }else{
                            for(var i=0;i<listMonth.length-2;i++){
                                monthRange.push(listMonth[i])
                            }
                            yearValues=yearValues+'(<kfpo:year> '+'"'+listYear[y]+'"'+')'
                            yearValues="values(?y ?year){"+yearValues+"}"
                        }
                        kingValues=kingValues+'(<kfpo:king> '+'"'+listKing[initKing]+'"'+')'
                        kingValues="values(?k ?king){"+kingValues+"}"
                        for(var m=0;m<monthRange.length;m++){
                            monthValues=monthValues+'(<kfpo:month> '+'"'+monthRange[m]+'"'+')'
                        }
                        monthValues="values(?m ?month){"+monthValues+"}"

                        var u="union"
                        if(y==finalYear){
                            union=union+'{'+kingValues+yearValues+monthValues+'}'
                        }else{
                            union=union+'{'+kingValues+yearValues+monthValues+'}'+u
                        }
                        other="?linkSource ?k ?king.\n\
                        ?linkSource ?m ?month.\n\
                        ?linkSource ?y ?year." 
                    }
                }
            }else{ // 5 6 7 8
                for(var k=initKing;k<=finalKing;k++){
                    var yearRange=[]
                    yearValues=""
                    monthValues=""
                    monthRange=[]
                    if(k==initKing){
                        for(var i=initYear;i<listYear.length-2;i++){
                            kingValues=""
                            monthValues=""
                            monthRange=[]
                            yearValues=""
                            yearRange=[]
                            if(i==initYear){
                                for(var j=initYear;j<=finalYear;j++){
                                    yearRange.push(listYear[j])
                                }
                                for(var j=initMonth;j<listMonth.length-2;j++){
                                    monthRange.push(listMonth[j])
                                }
                            }else{
                                yearRange.push(listYear[i])
                                for(var j=0;j<listMonth.length-2;j++){
                                    monthRange.push(listMonth[j])
                                }
                            }
                            kingValues=kingValues+'(<kfpo:king> '+'"'+listKing[initKing]+'"'+')'
                            kingValues="values(?k ?king){"+kingValues+"}"
                            for(var m=0;m<monthRange.length;m++){
                                monthValues=monthValues+'(<kfpo:month> '+'"'+monthRange[m]+'"'+')'
                            }
                            monthValues="values(?m ?month){"+monthValues+"}"
                            for(var y=0;y<yearRange.length;y++){
                                yearValues=yearValues+'(<kfpo:year> '+'"'+yearRange[y]+'"'+')'
                            }
                            yearValues="values(?y ?year){"+yearValues+"}"

                            union=union+'{'+kingValues+yearValues+monthValues+'}union'
                        }
                    }else if(k==finalKing){
                        kingValues=""
                        yearValues=""
                        monthValues=""
                        for(var j=0;j<=finalYear;j++){
                            yearRange.push(listYear[j])
                        }
                        for(var j=0;j<=finalMonth;j++){
                            monthRange.push(listMonth[j])
                        }
                        kingValues=kingValues+'(<kfpo:king> '+'"'+listKing[k]+'"'+')'
                        kingValues="values(?k ?king){"+kingValues+"}"
                        for(var y=0;y<yearRange.length;y++){
                            yearValues=yearValues+'(<kfpo:year> '+'"'+yearRange[y]+'"'+')'
                        }
                        for(var m=0;m<monthRange.length;m++){
                            monthValues=monthValues+'(<kfpo:month> '+'"'+monthRange[m]+'"'+')'
                        }
                        yearValues="values(?y ?year){"+yearValues+"}"
                        monthValues="values(?m ?month){"+monthValues+"}"
                        union=union+'{'+kingValues+yearValues+monthValues+'}'
                    }else{
                        if(k==initKing+1){
                            kingValues=""
                            kingValues=kingValues+'(<kfpo:king> '+'"'+listKing[k]+'"'+')'
                            kingValues="values(?k ?king){"+kingValues
                        }else if(k==finalKing-1){
                            for(var j=0;j<listYear.length-2;j++){
                                yearRange.push(listYear[j])
                            }
                            for(var j=0;j<listMonth.length-2;j++){
                                monthRange.push(listMonth[j])
                            }
                            for(var m=0;m<monthRange.length;m++){
                                monthValues=monthValues+'(<kfpo:month> '+'"'+monthRange[m]+'"'+')'
                            }
                            monthValues="values(?m ?month){"+monthValues+"}"
                            for(var y=0;y<yearRange.length;y++){
                                yearValues=yearValues+'(<kfpo:year> '+'"'+yearRange[y]+'"'+')'
                            }
                            kingValues=kingValues+'(<kfpo:king> '+'"'+listKing[k]+'"'+')}'
                            yearValues="values(?y ?year){"+yearValues+"}"
                            union=union+'{'+kingValues+yearValues+monthValues+'}union'
                            other="?linkSource ?k ?king.\n\
                                ?linkSource ?m ?month.\n\
                                ?linkSource ?y ?year." 
                        }else if(k>initKing+1 && k<finalKing-1){
                            kingValues=kingValues+'(<kfpo:king> '+'"'+listKing[k]+'"'+')'
                        } 
                    }
                }
                
            }
            $.when(executeRange(union,other,select,where)).done(function(res){
                console.log(res)
                printRes(res)
            })
        }else{
            document.getElementById("result").innerHTML="<h4 id='noData'>Inconsistent range!</h4>"
        }
    }
        

    if(selectedKingY=="" && selectedMonthY=="" && selectedYearY==""){
        if(orderBy==""){
            orderBy="?publication ?textNo ?collection ?collectionNo"
        }
        var query='PREFIX dcterms: <http://purl.org/dc/terms/>\n\
            PREFIX bibo: <http://purl.org/ontology/bibo/>\n\
            PREFIX o: <http://omeka.org/s/vocabs/o#>\n\
            select distinct ?IDSource ?publication ?textNo ?collection ?collectionNo ?linkSource '+ select+ '\n\
            where{\n\
                ?linkSource a <kfpo:KassiteSource>.\n\
                bind('+publication+' as ?publication)\n\
                bind('+textNo+' as ?textNo)\n\
                bind('+collection+' as ?collection)\n\
                bind('+collectionNo+' as ?collectionNo)\n\
                ?linkSource <kfpo:hasCuneiformTextId> ?publication.\n\
                ?linkSource bibo:number ?textNo.\n\
                ?linkSource <kfpo:collection> ?collection.\n\
                ?linkSource <kfpo:collectionNumber> ?collectionNo.\n\
                ?linkSource o:id ?IDSource\n\
                '+where+'\
            }order by '+orderBy
        

        $.when(executeAjax("https://fuseki.hfpo-kfpo.di.unito.it/KFPO/?query=",query)).done(function(res){
            printRes(res)
        });
    }
}

function printRes(res){
    //document.getElementById("collapsibleHead").checked=false
//alert("Cucu");

    var header=""
    var data=""
    var body=""
    var table=""
    var noData=""

    for(var i=0;i<res.head.vars.length;i++){
        if(res.head.vars[i]!=="IDSource"){
            header=header+'<th>'+res.head.vars[i]+'</th>'
        }
                    
    }
    header='<tr>'+header+'</tr>'

    for(var j=0;j<res.results.bindings.length;j++){
        data=""
        if(res.results.bindings[j].publication !== undefined){
            data=data+"<td>"+res.results.bindings[j].publication.value+"</td>"
        }
        if(res.results.bindings[j].textNo !== undefined){
            data=data+"<td>"+res.results.bindings[j].textNo.value+"</td>"
        }
        if(res.results.bindings[j].collection !== undefined){
            data=data+"<td>"+res.results.bindings[j].collection.value+"</td>"
        }
        if(res.results.bindings[j].collectionNo !== undefined){
            data=data+"<td>"+res.results.bindings[j].collectionNo.value+"</td>"
        }
        if(res.results.bindings[j].linkSource !== undefined){
            data=data+"<td><a href=https://kfpo.di.unito.it/s/KPR/item/"+
            res.results.bindings[j].IDSource.value+" target='_blank'>Go to source</a></td>"
        }   
        if(res.results.bindings[j].genre !== undefined){
            data=data+"<td>"+res.results.bindings[j].genre.value+"</td>"
        }
        if(res.results.bindings[j].subgenre !== undefined){
            data=data+"<td>"+res.results.bindings[j].subgenre.value+"</td>"
        }
        if(res.results.bindings[j].subjectMatter !== undefined){
            data=data+"<td>"+res.results.bindings[j].subjectMatter.value+"</td>"
        }
        if(res.results.bindings[j].sealedBy !== undefined){
            data=data+"<td>"+res.results.bindings[j].sealedBy.value+"</td>"
        }
        if(res.results.bindings[j].sealedWith !== undefined){
            data=data+"<td>"+res.results.bindings[j].sealedWith.value+"</td>"
        }
        if(res.results.bindings[j].typeOfSealing !== undefined){
            data=data+"<td>"+res.results.bindings[j].typeOfSealing.value+"</td>"
        }
        if(res.results.bindings[j].king !== undefined){
            data=data+"<td>"+res.results.bindings[j].king.value+"</td>"
        }
        if(res.results.bindings[j].year !== undefined){
            data=data+"<td>"+res.results.bindings[j].year.value+"</td>"
        }
        if(res.results.bindings[j].month !== undefined){
            data=data+"<td>"+res.results.bindings[j].month.value+"</td>"
        }
                    
            body=body+"<tr>"+data+"</tr>"
    }

    if(res.results.bindings.length == 0){
        noData = "<h4 id='noData'>No data available in table</h4>"
    }
                
    table="<table class='tResult'><h4>Showing "+ j +" entries</h4>"+header+body+"</table>"+noData
    //console.log(table);
    document.getElementById("result1").innerHTML=table ;           
}

function executeRange(union,other,select,where) {
    var query='PREFIX dcterms: <http://purl.org/dc/terms/>\n\
        PREFIX bibo: <http://purl.org/ontology/bibo/>\n\
        PREFIX o: <http://omeka.org/s/vocabs/o#>\n\
        select distinct ?IDSource ?publication ?textNo ?collection ?collectionNo ?linkSource'+ select+' ?king ?year ?month{\n\
        '+union+'\n\
        ?linkSource a <kfpo:KassiteSource>.\n\
        ?linkSource o:id ?IDSource.\n\
        ?linkSource <kfpo:hasCuneiformTextId> ?publication.\n\
        ?linkSource bibo:number ?textNo.\n\
        ?linkSource <kfpo:collection> ?collection.\n\
        ?linkSource <kfpo:collectionNumber> ?collectionNo.\n\
        '+other+'\n\
        '+where+'}'
        console.log(query)

    return $.ajax({
        url: "https://fuseki.hfpo-kfpo.di.unito.it/KFPO/?query="+encodeURIComponent(query),
        dataType: "jsonp", 
        error: function(){
            //console.log(error)
        }        
    });
}
