function clearFields(){
    var checkboxes=document.getElementsByClassName("check")

    for(var i=0;i<checkboxes.length;i++){
        checkboxes[i].checked=false
        $(document).ready(function() {
            $('.queryCol *').prop('disabled', false);
        });
    }
    document.getElementById("denominazione").value=""
    document.getElementById("gender").value=""
    document.getElementById("sexAge").value=""
    document.getElementById("profession").value=""
    document.getElementById("role").value=""
    document.getElementById("location").value=""
    document.getElementById("filiation").checked=false
    //document.getElementById("ethnonym").checked=false
    document.getElementById("roleInRel").checked=false
    document.getElementById("listSeal").checked=false
    document.getElementById("personAssociatedWith").checked=false
    document.getElementById("publication").value=""
    document.getElementById("textNo").value=""
    document.getElementById("collection").value=""
    document.getElementById("collectionNo").value=""
    document.getElementById("king").value=""
    document.getElementById("year").value=""
    document.getElementById("month").value=""
    //document.getElementById("personAssociatedWith").value=""
}

//PREFIX dcterms: <http://purl.org/dc/terms/> 
//PREFIX o: <http://omeka.org/s/vocabs/o#> 
//PREFIX bibo: <http://purl.org/ontology/bibo/> 
//select distinct ?IDName ?name where{ ?linkName a <kfpo:KassitePerson>. ?linkName dcterms:title ?name. ?linkName o:id ?IDName. }order by ?name


function searchIndividualRefined() {

    var query=""
    var selectedName=document.getElementById("denominazione").value
    var selectedGender=document.getElementById("gender").value
    var selectedSexAge=document.getElementById("sexAge").value
    var selectedProfession=document.getElementById("profession").value
    var selectedRole=document.getElementById("role").value
    var selectedLocation=document.getElementById("location").value
    //filtri se presenti
    var checkFiliation=document.getElementById("filiation").checked
    var checkListSeal=document.getElementById("listSeal").checked
    var roleInRelSwitch =  document.getElementById("roleInRelSwitch").checked
    var roleInRel =  document.getElementById("roleInRel").value
    var selectedPersonAssociateWith=document.getElementById("personAssociatedWith").value   
    var selectedPublication=document.getElementById("publication").value
    var selectedTextNo=document.getElementById("textNo").value
    var selectedCollection=document.getElementById("collection").value
    var selectedCollectionNo=document.getElementById("collectionNo").value   
    var selectedKing=document.getElementById("king").value
    var selectedYear=document.getElementById("year").value
    var selectedMonth=document.getElementById("month").value

    var where=""
    var select=""
    var name=""

    if(selectedName !== ""){
            var selectedNameLC=selectedName.toLowerCase()
            name='bind(replace(?name,?name,lcase(?name)) as ?lower)\
                filter(regex(?lower,"'+selectedNameLC+'"))'
        }
    if(selectedGender !== ""){
        select=select+" ?gender"
        where=where+' bind('+'"'+selectedGender+'"'+' as ?gender)\n\
                ?linkName <kfpo:gender> ?gender.\n'
    }
    if(selectedSexAge !== ""){
        select=select+" ?sexAge"
        where=where+' bind('+'"'+selectedSexAge+'"'+' as ?sexAge)\n\
                ?linkName <kfpo:sexAge> ?sexAge.\n'
    }
    if(selectedProfession !== ""){
        select=select+" ?profession"
        where=where+' bind('+'"'+selectedProfession+'"'+' as ?profession)\n\
                ?linkName <kfpo:titleInCuneiform> ?profession.\n'
    }
    if(selectedRole !== ""){
        select=select+" ?role"
        where=where+' bind('+'"'+selectedRole+'"'+' as ?role)\n\
                ?linkName <kfpo:hasRoleName> ?role.\n'
    }
    if(selectedLocation !== ""){
        select=select+" ?location"
        where=where+' bind('+'"'+selectedLocation+'"'+' as ?location)\n\
                ?linkName <kfpo:hasLocationName> ?location.\n'
    }
    //blocco filtri
    if(checkFiliation !== false){
            select=select+" ?filiation"
            where=where+' ?linkName <kfpo:hasPatronym> ?filiation.\n'
        }
    if(checkListSeal !== false){
            select=select+" ?IDSeal ?seal"
            where=where+' ?linkName <kfpo:hasSealSourceId> ?linkSeal.\n\
                    ?linkSeal dcterms:title ?seal.\
                    ?linkSeal o:id ?IDSeal'
        }
    if(roleInRelSwitch!==false){
            if (roleInRel=='Giver'){
            select=select+" ?nameFactoid "
            where=where+' ?linkFactoid a <kfpo:AdministrativeRelationshipFactoid>.\n\
                    ?linkFactoid dcterms:title ?nameFactoid.\n\
                    ?linkFactoid <kfpo:administrativeRelationType> ?type.\n\
                    values ?type{"gives to" "receives from"}\n\
                    ?linkFactoid <kfpo:pN1> ?linkName'} else {
                            select=select+" ?nameFactoid"
                            where=where+' ?linkFactoid a <kfpo:AdministrativeRelationshipFactoid>.\n\
                            ?linkFactoid dcterms:title ?nameFactoid.\n\
                            ?linkFactoid <kfpo:administrativeRelationType> ?type.\n\
                            values ?type{"gives to" "receives from"}\n\
                            ?linkFactoid <kfpo:pN2> ?linkName'
                    }
        }
    if(selectedPersonAssociateWith!==""){
            select=select+" ?IDSeal ?seal"
            where=where+' bind('+'"'+selectedPersonAssociateWith+'"'+' as ?seal)\n\
                ?linkName <kfpo:hasSealSourceId> ?linkSeal.\n\
                    ?linkSeal dcterms:title ?seal.\
                    ?linkSeal o:id ?IDSeal'
        }
    if(selectedPublication !== ""){
            select=select+" ?publication ?textNo"
            where=where+' bind('+'"'+selectedPublication+'"'+' as ?publication)\n\
                    ?linkName <kfpo:sourcedFrom> ?linkSource.\n\
                    ?linkSource <kfpo:hasCuneiformTextId> ?publication.'
        }
    if(selectedTextNo !== ""){
        select=select+" ?textNo ?publication"
        where=where+' bind('+'"'+selectedTextNo+'"'+' as ?textNo)\n\
                ?linkName <kfpo:sourcedFrom> ?linkSource.\n\
                ?linkSource bibo:number ?textNo.\
                ?linkSource <kfpo:hasCuneiformTextId> ?publication.'
    }
    if(selectedCollection !== ""){
        select=select+" ?collection"
        where=where+' bind('+'"'+selectedCollection+'"'+' as ?collection)\n\
                ?linkName <kfpo:sourcedFrom> ?linkSource.\n\
                ?linkSource <kfpo:collection> ?collection.'
    }
    if(selectedCollectionNo !== ""){
        select=select+" ?collectionNo"
        where=where+' bind('+'"'+selectedCollectionNo+'"'+' as ?collectionNo)\n\
                ?linkName <kfpo:sourcedFrom> ?linkSource.\n\
                ?linkSource <kfpo:collectionNumber> ?collectionNo.'
    }
    if(selectedKing !== ""){
        select=select+" ?king"
        where=where+' bind('+'"'+selectedKing+'"'+' as ?king)\n\
                ?linkName <kfpo:sourcedFrom> ?linkSource.\n\
                ?linkSource dcterms:title ?source.\n\
                ?linkSource <kfpo:king> ?king.'
    }
    if(selectedYear !== ""){
        select=select+" ?year"
        where=where+' bind('+'"'+selectedYear+'"'+' as ?year)\n\
                ?linkName <kfpo:sourcedFrom> ?linkSource.\n\
                ?linkSource dcterms:title ?source.\n\
                ?linkSource <kfpo:year> ?year.'
    }
    if(selectedMonth !== ""){
        select=select+" ?month"
        where=where+' bind('+'"'+selectedMonth+'"'+' as ?month)\n\
                ?linkName <kfpo:sourcedFrom> ?linkSource.\n\
                ?linkSource dcterms:title ?source.\n\
                ?linkSource <kfpo:month> ?month.'
    }


    query='PREFIX dcterms: <http://purl.org/dc/terms/>\n\
            PREFIX o: <http://omeka.org/s/vocabs/o#>\n\
            PREFIX bibo: <http://purl.org/ontology/bibo/>\n\
            select distinct ?IDName ?name '+ select+ '\n\
            where{\n\
                ?linkName a <kfpo:KassitePerson>.\n\
                ?linkName dcterms:title ?name.\n\
                ?linkName o:id ?IDName.\n\
                '+where+'\n\
                '+name+'\
            }order by ?name'


    if (roleInRelSwitch!==false) {
    query='PREFIX dcterms: <http://purl.org/dc/terms/>\n\
                PREFIX o: <http://omeka.org/s/vocabs/o#>\n\
                PREFIX bibo: <http://purl.org/ontology/bibo/>\n\
                select distinct ?IDName ?IDFactoid ?name '+ select+ '\n\
                where{\n\
                    ?linkName a <kfpo:KassitePerson>.\n\
                    bind(?name as ?name)\n\
                    ?linkName dcterms:title ?name.\n\
                    ?linkName o:id ?IDName.\n\
                    ?linkFactoid o:id ?IDFactoid.\n\
                    '+where+'\
                }order by ?name'

    }


    console.log(query);

    //$.when(executeAjax("https://fuseki.hfpo-kfpo.di.unito.it/KFPO/?query=",query)).done(function(res){
    //https://fuseki.hfpo-kfpo.di.unito.it/#/dataset/KFPO/query
    $.when(executeAjax("https://fuseki.hfpo-kfpo.di.unito.it/KFPO/?query=",query)).done(function(res){
        console.log(res)
        console.log(query)

        var header=""
        var data=""
        var body=""
        var table=""
        var noData=""

        for(var i=0;i<res.head.vars.length;i++){
            //&& res.head.vars[i]!=="nameFactoid"
            if(res.head.vars[i]!=="IDName" && res.head.vars[i]!=="IDFactoid" && res.head.vars[i]!=="IDSeal"  ){
                header=header+'<th>'+res.head.vars[i]+'</th>'
            }  
        }
        header='<tr>'+header+'</tr>'

        for(var j=0;j<res.results.bindings.length;j++){
            data=""
            if(res.results.bindings[j].name !== undefined){
                data=data+"<td><a href=https://kfpo.di.unito.it/s/KPR/item/"+
                res.results.bindings[j].IDName.value+" target='_blank'>"
                +res.results.bindings[j].name.value+"</a></td>"
            }    
            if(res.results.bindings[j].gender !== undefined){
                data=data+"<td>"+res.results.bindings[j].gender.value+"</td>"
            }
            if(res.results.bindings[j].sexAge !== undefined){
                data=data+"<td>"+res.results.bindings[j].sexAge.value+"</td>"
            }
            if(res.results.bindings[j].profession !== undefined){
                data=data+"<td>"+res.results.bindings[j].profession.value+"</td>"
            }
            if(res.results.bindings[j].role !== undefined){
                data=data+"<td>"+res.results.bindings[j].role.value+"</td>"
            }
            if(res.results.bindings[j].location !== undefined){
                data=data+"<td>"+res.results.bindings[j].location.value+"</td>"
            }
            if(res.results.bindings[j].filiation !== undefined){
                    data=data+"<td>"+res.results.bindings[j].filiation.value+"</td>"
                }
            if(res.results.bindings[j].seal !== undefined){
                    data=data+"<td><a href=https://kfpo.di.unito.it/s/KPR/item/"+
                    res.results.bindings[j].IDSeal.value+" target='_blank'>"
                    +res.results.bindings[j].seal.value+"</a></td>"
                } 
            if(res.results.bindings[j].publication !== undefined){
                data=data+"<td>"+res.results.bindings[j].publication.value+"</td>"
            }
            if(res.results.bindings[j].textNo !== undefined){
                data=data+"<td>"+res.results.bindings[j].textNo.value+"</td>"
            }
            if(res.results.bindings[j].collection !== undefined){
                data=data+"<td>"+res.results.bindings[j].collection.value+"</td>"
            }
            if(res.results.bindings[j].collectionNo !== undefined){
                data=data+"<td>"+res.results.bindings[j].collectionNo.value+"</td>"
            }
            if(res.results.bindings[j].king !== undefined){
                data=data+"<td>"+res.results.bindings[j].king.value+"</td>"
            }
            if(res.results.bindings[j].year !== undefined){
                data=data+"<td>"+res.results.bindings[j].year.value+"</td>"
            }
            if(res.results.bindings[j].month !== undefined){
                data=data+"<td>"+res.results.bindings[j].month.value+"</td>"
            }
            
            if(res.results.bindings[j].nameFactoid !== undefined){
                    data=data+"<td><a href=https://kfpo.di.unito.it/s/KPR/item/"+
                    res.results.bindings[j].IDFactoid.value+" target='_blank'>"
                    +res.results.bindings[j].nameFactoid.value+"</a></td>"
                }
            
            body=body+"<tr>"+data+"</tr>"
            

        }

        if(res.results.bindings.length == 0){
                noData = "<h4 ID='noData'>No data available in table</h4>"
            }
            
        table="<table class='tResult'><h4>Showing "+ j +" entries</h4>"+header+body+"</table>"+noData
        //+"<br\>"+query
        document.getElementById("result").innerHTML=table;


    });
}

function searchIndividualAggregated() {
        var query=""
        var select=""
        var where=""
        var groupBy=""
        var selectedCheck=""
        var checkboxes=document.getElementsByClassName("checkbox-round")

        for(var i=0;i<checkboxes.length;i++){
            if(checkboxes[i].checked==true){
                selectedCheck=checkboxes[i].value
            }
        }

        if(selectedCheck=="totGender"){
            select="?gender"
            where="?link <kfpo:gender> ?gender."
            groupBy=select
        }

        if(selectedCheck=="totSexAge"){
            select="?sexAge"
            where="?link <kfpo:sexAge> ?sexAge."
            groupBy=select
        }

        if(selectedCheck=="totProfession"){
            select="?profession"
            where="?link <kfpo:titleInCuneiform> ?profession."
            groupBy=select
        }
        if(selectedCheck=="totRole"){
            select="?role"
            where="?link <kfpo:hasRoleName> ?role."
            groupBy=select
        }
        if(selectedCheck=="totLocation"){
            select="?location"
            where="?link <kfpo:hasLocationName> ?location."
            groupBy=select
        }

        query='PREFIX dcterms: <http://purl.org/dc/terms/>\n\
                select '+ select+ ' (count(?link) as ?tot)\n\
                where{\n\
                    ?link a <kfpo:KassitePerson>.\n\
                    '+where+'\n\
                }group by '+groupBy +' order by desc(?tot)'
        console.log(query)

        

        $.when(executeAjax("https://fuseki.hfpo-kfpo.di.unito.it/KFPO/?query=",query)).done(function(res){
            console.log(res)
            console.log(query)

            var header=""
            var data=""
            var body=""
            var table=""
            var noData=""

            for(var i=0;i<res.head.vars.length;i++){
                if(res.head.vars[i]!=="IDName" && res.head.vars[i]!=="IDFactoid" && res.head.vars[i]!=="IDSeal"){
                    header=header+'<th>'+res.head.vars[i]+'</th>'
                }  

            }
            header='<tr>'+header+'</tr>'

            for(var j=0;j<res.results.bindings.length;j++){
                data=""
                if(res.results.bindings[j].gender !== undefined){
                    data=data+"<td>"+res.results.bindings[j].gender.value+"</td>"
                }
                if(res.results.bindings[j].sexAge !== undefined){
                    data=data+"<td>"+res.results.bindings[j].sexAge.value+"</td>"
                }
                if(res.results.bindings[j].profession !== undefined){
                    data=data+"<td>"+res.results.bindings[j].profession.value+"</td>"
                }
                if(res.results.bindings[j].role !== undefined){
                    data=data+"<td>"+res.results.bindings[j].role.value+"</td>"
                }
                if(res.results.bindings[j].location !== undefined){
                    data=data+"<td>"+res.results.bindings[j].location.value+"</td>"
                }
                if(res.results.bindings[j].tot !== undefined){
                    data=data+"<td>"+res.results.bindings[j].tot.value+"</td>"
                }

                body=body+"<tr>"+data+"</tr>"      

            }

        if(res.results.bindings.length == 0){
                noData = "<h4 ID='noData'>No data available in table</h4>"
            }
            
        table="<table class='tResult'><h4>Showing "+ j +" entries</h4>"+header+body+"</table>"+noData
        //+"<br\>"+query
        document.getElementById("result").innerHTML=table;
            
        });
        

}



