function takeKg(cl,id){
    var query="PREFIX dcterms: <http://purl.org/dc/terms/>\
                select ?v\
                where{\
                ?link a <kfpo:"+cl+">.\
                ?link dcterms:title ?v\
                }order by ?v"

    $.when(executeAjax("https://fuseki.hfpo-kfpo.di.unito.it/KFPO/?query=",query)).done(function(res){
        //console.log(query);
        var opt="";
        var ordered = [];
            for(var i=0;i<res.results.bindings.length;i++){
                //console.log("elemento: " + res.results.bindings[i].v.value);
                ordered.push(res.results.bindings[i].v.value);
                //opt=opt+'<option value="'+res.results.bindings[i].v.value+'"></option>'
            }
                //ordered.sort(Intl.Collator("sl",{ sensitivity: "base" }).compare);
                ordered.sort(Intl.Collator("sl").compare);
                console.log(ordered);                

            for(var i=0;i<ordered.length;i++){
                opt=opt+'<option value="'+ordered[i]+'"></option>'
            }

                document.getElementById(id).innerHTML=opt
    });
}

function takeCustom(num,id,order){
    $.when(executeAjax("https://kfpo.di.unito.it/api/custom_vocabs/"+num,"")).done(function(res){
        var stringToJSON=JSON.stringify(res)
        var myEscapedJSONString=stringToJSON.replaceAll(/o:terms/g,"oterms")
        var json=JSON.parse(myEscapedJSONString)
        var opt=""
        var split = json.oterms;
        // cambiata per modifica API
        // ricavo l'array splittato per \n (vecchia API)
        // var split=json.oterms.split("\n")
        //if(order==true){
        //    split.sort(function(a,b){
        //        return a.localeCompare(b)
        //    })
        //}
        // fine cambiamento Rossana
        for(var i=0;i<split.length;i++){
            opt=opt+'<option value="'+split[i]+'"></option>'
        }
        document.getElementById(id).innerHTML=opt
    });
}

function executeAjax(url, query){
    return $.ajax({
        url: url+encodeURIComponent(query),
        type: "get",
        dataType: "jsonp",
        error: function(){
            alert("An Error as occured!")
        }
    })
}

function checkCount(){
    $(document).ready(function(){
        $('[class="check"]').change(function(){
            if(this.checked){
                $('[class="check"]').not(this).prop('checked', false);
                //disable
                $(document).ready(function() {
                    $('.queryCol *').prop('disabled', true);
                });

            }
            if(this.checked==false){
                //enable
                $(document).ready(function() {
                    $('.queryCol *').prop('disabled', false);
                }); 
            }    
        });
        //enable
        $(document).ready(function() {
            $('.queryCol *').prop('disabled', false);
        });
    });
}
/*
function putDiacritics(x){
    const focusText=document.getElementById("focusText")
    if(focusText.textContent!==""){
        const inputText=document.getElementById(focusText.textContent)
        var cursorPos = $("#"+focusText.textContent).prop('selectionStart');
		var v = $("#"+focusText.textContent).val();
		var textBefore = v.substring(0,  cursorPos);
		var textAfter  = v.substring(cursorPos, v.length);

       $("#"+focusText.textContent).val(textBefore + x.textContent+ textAfter);

		inputText.focus()
    }
}

function clickOnDocument(e){
    const focusText=document.getElementById("focusText")
    if(e.target.classList.contains("focusText")){
        focusText.innerHTML=e.target.id
    }else if(e.target.classList.contains("TDDiacritics")){
        putDiacritics(e.target)
    }else{
        //focusText.textContent=""
    }
}
*/
function putDiacritics(x){
    const focusText=document.getElementById("focusText")
    if(focusText.textContent!==""){
        const inputText=document.getElementById(focusText.textContent)
        var cursorPos = $("#"+focusText.textContent).prop('selectionStart');
		var v = $("#"+focusText.textContent).val();
		var textBefore = v.substring(0,  cursorPos);
		var textAfter  = v.substring(cursorPos, v.length);

       $("#"+focusText.textContent).val(textBefore + x.textContent+ textAfter);

		inputText.focus()
    }
}



function clickOnDocument(e){
    const focusText=document.getElementById("focusText")
    //if(e.target.classList.contains("focusText")){
    if(e.target.classList.contains("stile-datalist")){
        focusText.innerHTML=e.target.id
    }else if(e.target.classList.contains("TDDiacritics")){
        putDiacritics(e.target)
    }else{
        if (!(e.target.classList.contains("button-diacritics"))) {focusText.textContent=""}
    }
}